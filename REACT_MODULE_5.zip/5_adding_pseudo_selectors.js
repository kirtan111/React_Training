// File: App.css


.App {
	text-align: center;
}

.red {
    color: red;
}

.bold {
    font-weight:lighter
}

.App button {
	border: 1px solid blue;
	padding: 15px;
	background-color: green;
	font: inherit;
  color: white;
  cursor:pointer;
  border-radius: 9px;
}

.App button:hover {
    background-color: red;
    color: black;
}
