// #TASK: 

// const arr = [10,{item: {a:{val:[10,20]}}},2,3,4,];

// const [,{item: {a: {val: [x, y]}}},,,,] = arr
// console.log(x)
