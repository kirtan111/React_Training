    Primitive Data Types :
	    String
	    Number
	    Boolean
	    Null
	    Undefined
	    
    
    Reference Data Types :
	    Object
	    Array
	    Function
	    Date
	    RegExp
	    Map
	    Set



// const person = {
//     name : "KK"
// };
// const SecondPerson = person;
// person.name = "Kirtan";
// console.log(SecondPerson); // {name : 'KK'}




// const person = {
//     name : "KK"
// };
// const SecondPerson = { ...person};
// person.name = "Kirtan";
// console.log(SecondPerson); // {name : 'Kirtan'}
