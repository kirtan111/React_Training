// let Name = "KK";
// let Name = "not my name"; // redeclaration
// console.log(Name); //output => SyntaxError: Identifier 'Name' has already been declared




// let Name = "KK";
// Name = "Kirtan Thummar"; // update Name
// console.log(Name); //output => "Kirtan Thummar"




// if(true) {
//     let Name = "KK";
//     console.log(Name);
// }
// console.log(Name); //output =>  ReferenceError: Name is not defined (Becauseof block scoped)




// const Name = "KK";
// Name = "not my name";
// console.log(Name); //output => TypeError: invalid assignment to const 'Name'




// if(true) {
//     const Name = "KK"; // output => KK
//     console.log(Name);
// }
// console.log(Name); //output =>  ReferenceError: Name is not defined




// const Name;
// console.log(Name); // output => SyntaxError: Missing initializer in const declaration



// let Name;
// console.log(Name); // output => undefined




// let Name;
// if(true) {
//     const Name = "Kirtan"; // output => Kirtan
//     console.log(Name);
// }
// console.log(Name);//output => undefined
