// let numbers = [1, 2, 3, 4];
// let fruits = ["Banana", "Apple", "Kiwi", "Kamalam"]


// // map
// let squares = numbers.map(num => num * num);
// console.log(squares); // Output: [ 1, 4, 9, 16 ]


// // Filter
// let evens = numbers.filter(num => num % 2);
// console.log(evens); // Output: [ 1, 3 ]


// // Reduce
// const sum = numbers.reduce((curr, next) => {
//     return curr + next;
// }, 0);
// console.log(sum); // Output: 10


// // forEach
// numbers.forEach(function(number) {
// 	console.log(number);
// }); // output: 1 2 3 4 (in list view)


// // sort
// let newnumber = [5,9,3,7,5]
// const sortedNumbers = newnumber.sort((a, b) => a - b);
// console.log(sortedNumbers); // output: [3, 5, 5, 7, 9]


// // slice
// let cut = fruits.slice(1, 3);
// console.log(cut); // Output: [ 'Apple', 'Kiwi' ]


// // splice
// fruits.splice(2, 1, 'KK');
// console.log(fruits); // Output: [ 'Banana', 'Apple', 'KK', 'Kamalam' ]
