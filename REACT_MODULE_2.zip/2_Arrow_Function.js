// hey = function () {
//     return "Hello KK!"
// } 
// console.log(hey()) // output => Hello KK!




// hey = () => {return "Hello KK!" }
// console.log(hey()); // output => Hello KK!




// setTimeout(() => {
// 	alert("Hello!")
// }, 3000); // output => Hello! (after 3 seconds)



// Syntax:
// (parmeter1, parameter2) => expression
// (parameter1, parameter2) => { statements }
