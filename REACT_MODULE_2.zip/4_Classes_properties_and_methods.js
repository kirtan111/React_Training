// class MyClass {
// 	constructor(name) {
// 		this.name = name;
// 	}
// 	sayHello() {
// 		console.log(`hello my name is ${this.name}`);
// 	}
// }

// const Obj = new MyClass("KK"); // class instance
// Obj.sayHello(); // logs "hello my name is KK"

// here,
// MyClass = Name of the class, 
// name = argument of constructor,
// sayHello = method of the class




// class myClass {
//     static myStaticProp = 'static';
//     myInstanceProp = 'instance';

//     constructor() {
//         console.log(myClass.myStaticProp); // static
//         console.log(this.myInstanceProp); // instance
//     }

//     myMethod() {
//         console.log('hello there');
//     }
// }

// const instance = new myClass();
// console.log(instance.myMethod()); // hello there
// console.log(myClass.myStaticProp); // static
// console.log(myClass.myInstanceProp); // undefined
// console.log(instance.myInstanceProp); // instance
