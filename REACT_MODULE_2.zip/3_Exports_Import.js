// #TASK:
// Que: export these variables but "A" as a default export and rest of other variables as normal export
// const A = "a";
// const B = "b";
// const C = "c";
// const D = "d";


// ANS:
// export default A = "a";
// const B = "b";
// const C = "c";
// const D = "d";
// export {B, C, D}

// import A from './path'
// import {B, C, D} from './path'



// NOTES: 

// Importing default export:
// import GIVEN_NAME from ADDRESS
    
// Importing named values:
// import { PARA_NAME } from ADDRESS
    
// Importing a combination of Default Exports and Named Values:
// import GIVEN_NAME, { PARA_NAME, ... } from ADDRESS
    
// Exporting default export:
// export default GIVEN_NAME
    
// Exporting named values:
// export { PARA_NAME }
