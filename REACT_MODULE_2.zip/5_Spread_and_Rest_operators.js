// Spread Operator:

// var arr1 = [10, 20, 30, 40, 50];
// var arr2 = [60, 70, 80, 90, 100];
// var arr3 = [...arr1, ...arr2];
// console.log(arr3); // [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]




// Rest Operator:

// average = (...args) => {
//     console.log(args);
//     var avg =
//         args.reduce((a, b) => {
//             return a + b;
//         }, 0) / args.length;
//     return avg;
// }
// console.log("average of numbers is : " + average(1, 2, 3, 4, 5)); // [1, 2, 3, 4, 5] "average of numbers is : 3"
// console.log("average of numbers is : " + average(1, 2, 3)); // [1, 2, 3] "average of numbers is : 2"



// when you create a function defination, you may want to leave room for additional parameters, and if so, you can use a rest parameter. A function defination can have only one rest parameter, and it must be the last parameter.The values passed in with the rest parameter will be provided to the function inside an array. . It's literally the rest of the parameters. Notice thet with rest parameters we are condinsing value into a single element or object thet we can refer to.


// However, spread syntax expands an array into it's individual elements or an object into its individual properties. We can take an array and spread the individual elements into a function callas arguments, or we can spread the elements into a new array po the properties into a new object as is common in react and functional programming.
