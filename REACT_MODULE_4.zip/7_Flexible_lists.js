// File: App.js


import React, { useState } from "react";
// import Details from "./Details";
import Person from "./Person";
// import "./Person.css";

const App = () => {
    const [persons, setPersons] = useState({
        person: [
            { id: "1", name: "KK", age: 21 },
            { id: "2", name: "OM", age: 21 },
            { id: "3", name: "RAJ", age: 24 },
        ],
        showPerson: false,
    });

    const newChangeName = (e, id) => {

        const pIndex = persons.person.findIndex( p => p.id === id );
        console.log(pIndex);
        const per = {...persons.person[pIndex]};
        console.log(per);
        per.name = e.target.value;
        const pp = [...persons.person];
        pp[pIndex] = per;
        setPersons({person: pp})
        // setPersons({
        //     person: [
        //         { id: "1", name: "Kirtan Thummar", age: 21 },
        //         { id: "2", name: "Tejas Rangani", age: 25 },
        //         { id: "3", name: "Khushi Sakhiya", age: 3.5 },
        //     ],
        //     showPerson: persons.showPerson,
        // });
    };

    // const togglePersonsHandler = () => {
    //     // const doesShow = persons.showPerson;
    //     // setPersons({ showPerson: !doesShow });
    //     setPersons((prevState) => {
    //         return {
    //             ...prevState,
    //             showPerson: !prevState.showPerson,
    //         };
    //     });
    // };

    // let people = null;

    // if (persons.showPerson) {
    //     people = (
    //         <div>
    //             <Person name={persons.person[0].name} age={persons.person[0].age} />
    //             <Person name={persons.person[1].name} age={persons.person[1].age} />
    //             <Person name={persons.person[2].name} age={persons.person[2].age} changed={newChangeName} />
    //         </div>
    //     );
    // }

    const deletePerson = (personIndex) => {
        // const person = persons.person.splice(); //.splice() method
        const person = [...persons.person]; // spread operator
        person.splice(personIndex, 1);
        setPersons({ person: person });
    };

    let people = null;

    if (!persons.showPerson) {
        people = (
            <div>
                {persons.person.map((pupil, index) => {
                    return <Person click={() => deletePerson(index)} name={pupil.name} age={pupil.age} key={pupil.id} changed={e => newChangeName(e, pupil.id)} />
                })}
            </div>
        );
    }

    return (
        <div className="App">
            <h1>Heading</h1>
            <button className="switchNameBtn" onClick={newChangeName} > Switch Name </button>
            {people}
        </div>
    );
};

export default App;


// File: Person.js


import React from "react";
const person = (props) => {
    return (
        <div>
            <p>
                Hello, my name is {props.name} and i am {props.age} year old!{" "}
            </p>
            <p> {props.children} </p>
            <input type="text" onChange={props.changed} value={props.name} />
        </div>
    );
};
export default person;
