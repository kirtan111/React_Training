// File:App.js

import React, { useState } from "react";
// import Details from "./Details";
import Person from "./Person";
import "./Person.css";

const App = () => {
    const [persons, setPersons] = useState({
        person: [
            { name: "KK", age: 21 },
            { name: "OM", age: 21 },
            { name: "RAJ", age: 24 },
        ],
        showPerson: false,
    });

    // const newChangeName = (e) => {
    //     setPersons({
    //         person: [
    //             { name: "Kirtan Thummar", age: 21 },
    //             { name: "Tejas Rangani", age: 25 },
    //             { name: e.target.value, age: 3.5 },
    //         ],
    //         showPerson: persons.showPerson,
    //     });
    // };

    // const togglePersonsHandler = () => {
    //     // const doesShow = persons.showPerson;
    //     // setPersons({ showPerson: !doesShow });
    //     setPersons((prevState) => {
    //         return {
    //             ...prevState,
    //             showPerson: !prevState.showPerson,
    //         };
    //     });
    // };

    // let people = null;

    // if (persons.showPerson) {
    //     people = (
    //         <div>
    //             <Person name={persons.person[0].name} age={persons.person[0].age} />
    //             <Person name={persons.person[1].name} age={persons.person[1].age} />
    //             <Person name={persons.person[2].name} age={persons.person[2].age} changed={newChangeName} />
    //         </div>
    //     );
    // }

    const deletePerson = (personIndex) => {
        const person = persons.person;
        person.splice(personIndex, 1);
        setPersons({ person: person });
    };

    let people = null;

    if (!persons.showPerson) {
        people = (
            <div>
                {persons.person.map((pupil, index) => {
                    return <Person click={() => deletePerson(index)} name={pupil.name} age={pupil.age} />;
                })}
            </div>
        );
    }

    return (
        <div className="App">
            <h1>Heading</h1>
            <button className="switchNameBtn">Switch Name</button>
            {people}
        </div>
    );
};

export default App;


// File: Person.js

import React from "react";
import "./Person.css";

const Person = (props) => {
    return (
        <div className="Person">
            <p onClick={props.click}>
                Hello, my name is {props.name} and i am {props.age} year old!{" "}
            </p>
            <p> {props.children} </p>
            <input type="text" onChange={props.changed} />
        </div>
    );
};
export default Person;

