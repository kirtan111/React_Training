// File.js

import React, { useState } from "react";
// import Details from "./Details";
import Person from "./Person";

const App = () => {
    const [persons, setPersons] = useState([
        { name: "KK", age: 23 },
        { name: "OM", age: 12 },
        { name: "RAJ", age: 34 },
    ]);

    const switchNameHandler = () => {
        setPersons([
            { name: "Kirtan Thummar", age: 21 },
            { name: "Tejas Rangani", age: 25 },
            { name: "Khushi sakhiya", age: 3.5 },
        ]);
    };
    // const [count, setCount] = useState(0);

    // const AddCount = () => {
    //     return setCount(count + 1);
    // };

    // const handleClick = () => {
    //     console.log("Hello KIRTAN !");
    // };

    // const title = <h5> Click Me !</h5>;

    // const login = true;

    // if (login) {
    //     console.log("welcome to web....");
    // } else {
    //     console.log("please login first !");
    // }

    return (
        <div className="App">
            {/* <h1> Hello KK! </h1>

            <p> {title ? "Done" : "Motu"} </p>

            <p> I am a Person and i am {Math.floor(Math.random() * 30)} year old!</p>

            <Details name="KK" age={21}>
                {" "}
                Chilren of Details 1{" "}
            </Details>
            <Details name="KAKA" age={98}>
                {" "}
                Children of Datails 2{" "}
            </Details>

            <button onClick={handleClick}> {title} </button> */}

            {/* <form
                onSubmit={(e) => {
                    alert("submitted sucessfully");
                    e.preventDefault();
                }}
            >
                <button type="submit"> Submit ! </button>
            </form>

            <button onClick={AddCount}> {count} </button> */}

            <h1>Heading</h1>
            <button onClick={switchNameHandler}>Switch Name</button>
            <Person name={persons[0].name} age={persons[0].age} />
            <Person name={persons[1].name} age={persons[1].age} />
            <Person name={persons[2].name} age={persons[2].age} />
        </div>
    );
};

export default App;



// Person.js

import React from "react";
const person = (props) => {
    return (
        <div>
            <p>
                I am a {props.name} and i am {props.age} year old!{" "}
            </p>
            <p> {props.children} </p>
        </div>
    );
};
export default person;

