import React from "react";

const App = () => {
    const handleClick = () => {
        console.log("Hello KIRTAN !");
    };

    const title = <h5> Click Me !</h5>;

    const login = true;

    if (login) {
        console.log("welcome to web....");
    } else {
        console.log("please login first !");
    }

    return (
        <div className="App">
            <h1> Hello KK! </h1>
            <p> {title ? "Done" : "Motu"} </p>
            <p> I am a Person and i am {Math.floor(Math.random() * 30)} year old!</p> // Dynamic content
            <button onClick={handleClick}> {title} </button>
        </div>
    );
};

export default App;
