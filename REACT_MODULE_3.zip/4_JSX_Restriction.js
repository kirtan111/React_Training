// You can’t use JavaScript expressions directly in the JSX code, you have to wrap them in curly braces.

// You can’t use if statements or for loops directly in JSX, you have to use conditional rendering for them.

// You need to close every tag that you open in JSX.

// In JSX, you can’t use the reserved words such as 'class' and 'for' as attribute names. Instead, you have to use 'className' and 'htmlFor' respectively.

import React from "react";

const App = () => {
    const handleClick = () => {
        console.log("Hello KIRTAN !");
    };

    const login = true;

    if (login) {
        console.log("welcome to web....");
    } else {
        console.log("please login first !");
    }

    return (
        <div className="App">
            <h1> Hello KK! </h1>
            <button onClick={handleClick}> Enter </button>
        </div>
    );
};

export default App;
