// File: App.js

import React, { useState } from "react";
// import Details from "./Details";
import Person from "./Person";

const App = () => {
    const [persons, setPersons] = useState([
        { name: "KK", age: 21 },
        { name: "OM", age: 21 },
        { name: "RAJ", age: 24 },
    ]);

    const changeName = () => {
        setPersons([
            { name: "Kirtan Thummar", age: 21 },
            { name: "Tejas Rangani", age: 25 },
            { name: "Khushi sakhiya", age: 3.5 },
        ]);
    };

    const newChangeName = (e) => {
        setPersons([
            { name: "Kirtan Thummar", age: 21 },
            { name: "Tejas Rangani", age: 25 },
            { name: e.target.value, age: 3.5 },
        ]);
    };
    // const [count, setCount] = useState(0);

    // const AddCount = () => {
    //     return setCount(count + 1);
    // };

    // const handleClick = () => {
    //     console.log("Hello KIRTAN !");
    // };

    // const title = <h5> Click Me !</h5>;

    // const login = true;

    // if (login) {
    //     console.log("welcome to web....");
    // } else {
    //     console.log("please login first !");
    // }

    return (
        <div className="App">
            {/* <h1> Hello KK! </h1>

            <p> {title ? "Done" : "Motu"} </p>

            <p> I am a Person and i am {Math.floor(Math.random() * 30)} year old!</p>

            <Details name="KK" age={21}>
                {" "}
                Chilren of Details 1{" "}
            </Details>
            <Details name="KAKA" age={98}>
                {" "}
                Children of Datails 2{" "}
            </Details>

            <button onClick={handleClick}> {title} </button> */}

            {/* <form
                onSubmit={(e) => {
                    alert("submitted sucessfully");
                    e.preventDefault();
                }}
            >
                <button type="submit"> Submit ! </button>
            </form>

            <button onClick={AddCount}> {count} </button> */}

            <h1>Heading</h1>
            <button onClick={changeName}>Switch Name</button>
            <Person name={persons[0].name} age={persons[0].age} />
            <Person name={persons[1].name} age={persons[1].age} />
            <Person changed={newChangeName} name={persons[2].name} age={persons[2].age} />
        </div>
    );
};

export default App;


// File: Person.js

import React from "react";
const person = (props) => {
    return (
        <div className="Person" >
            <p>
                Hello, my name is {props.name} and i am {props.age} year old!{" "}
            </p>
            <p> {props.children} </p>
            <input type="text" onChange={props.changed} />
        </div>
    );
};
export default person;


// FIle: Person.css

.Person {
    width: 60%;
    margin: 16px auto;
    border: 1px solid #eee;
    box-shadow: 0 2px 3px #ccc;
    padding: 16px;
    text-align: center;
}