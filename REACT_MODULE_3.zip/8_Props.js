// File: App.js

import React from "react";
import Details from "./Details";

const App = () => {
    const handleClick = () => {
        console.log("Hello KIRTAN !");
    };

    const title = <h5> Click Me !</h5>;

    const login = true;

    if (login) {
        console.log("welcome to web....");
    } else {
        console.log("please login first !");
    }

    return (
        <div className="App">
            <h1> Hello KK! </h1>

            <p> {title ? "Done" : "Motu"} </p>

            <p> I am a Person and i am {Math.floor(Math.random() * 30)} year old!</p>

            <Details name="KK" age={21}></Details>

            <button onClick={handleClick}> {title} </button>
        </div>
    );
};

export default App;



// File: Details.js

import React from "react";

function Details(props) {
    return (
        <div>
            <p>My name is {props.name}.</p>
            <p>I am {props.age} years old.</p>
        </div>
    );
}

export default Details;
