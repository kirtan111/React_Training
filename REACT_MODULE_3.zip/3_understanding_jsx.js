import React from "react";

const App = () => {
    return (
        <div className="App">
            <h1> Hello KK! </h1>
        </div>
    );
};

export default App;
