import React from "react";

const App = () => {
    const handleClick = () => {
        console.log("Hello KIRTAN !");
    };

    const login = true;

    if (login) {
        console.log("welcome to web....");
    } else {
        console.log("please login first !");
    }

    return (
        <div className="App">
            <h1> Hello KK! </h1>
            <button onClick={handleClick}> Enter </button>
        </div>
    );
};

export default App;
